//
// Created by alex on 3/9/20.
//
#include <iostream>
#include "Book.h"
#include <sstream>

using namespace std;

// Privzeti
Book::Book() : title("None"), publisher("None"), pages(0) {
}

// Kopirni
Book::Book(const Book& b) : title(b.title), publisher(b.publisher), pages(b.pages) {
}

// Konstruktor
Book::Book(string title1, string publisher1, int pages1) : title(title1), publisher(publisher1), pages(pages1) {
}

// Destruktor
Book::~Book() {
}


// METODE
void Book::setTitle(string title1) {
    title = title1;
}

void Book::setPublisher(string publ) {
    publisher = publ;
}

void Book::setPages(int pages1) {
    pages = pages1;
}

void Book::setPagesRead(int pagesRead1) {
    pagesRead = pagesRead1;
}

string Book::getTitle() {
    return title;
}

string Book::getPublisher() {
    return publisher;
}

int Book::getPages() {
    return pages;
}

void Book::print() {
    cout << "Title: " << title << endl;
    cout << "Publisher: " << publisher << endl;
    cout << "Pages: " << pages << endl;
}

string Book::toString() {

    stringstream bookInfo;
    bookInfo << "Title: " <<  title << ", Publisher: " <<  publisher << ", Pages: " << pages << ".";

    return bookInfo.str();
}

int Book::pagesToFinish() {
    return (pages - pagesRead);
}

#include "Book.h"
