//
// Created by alex on 3/9/20.
//

#include<iostream>

using namespace std;

#ifndef NALOGA0201_BOOK_H
#define NALOGA0201_BOOK_H


class Book {
private:
    string title;
    string publisher;
    int pages;
    int pagesRead;
public:
    // Privzeti
    Book();
    // Kopirni
    Book(const Book& b);
    // Konstruktor
    Book(string title, string publisher, int pages);
    // Destruktor
    ~Book();

    // Metode
    void setTitle(string title1);
    void setPublisher(string publ);
    void setPages(int pages1);
    void setPagesRead(int pagesRead1);
    string getTitle();
    string getPublisher();
    int getPages();
    void print();
    string toString();
    int pagesToFinish();
};


#endif //NALOGA0201_BOOK_H
