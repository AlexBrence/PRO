#include <iostream>
#include "Book.h"

using namespace std;


int main() {
    Book a;
    Book b("Janko in Metka", "Nevemvec", 165);
    Book c(b);

    a.print();
    cout << endl;

    b.print();
    cout << endl;

    c.print();
    cout << endl;

    Book *d = new Book();
    Book *e = new Book("Metka in Janko", "Pojmanimam", 50);
    Book *f = new Book(*e);

    d->print();
    cout << endl;

    e->print();
    cout << endl;

    f->print();
    cout << endl;

    a.setTitle("Programiranje2");
    a.setPublisher("ProfNaFeriju");
    a.setPages(100);

    cout << "Title: " << a.getTitle() << endl << "Publisher: " << a.getPublisher() << endl << "Pages: " << a.getPages() << "." << endl << endl;

    cout << "-----To string method-----" << endl;
    cout << e->toString() << endl << endl;

    e->setPagesRead(14);
    cout << "Pages to finish: " << e->pagesToFinish() << endl << endl;

    delete d;
    delete e;
    delete f;
}