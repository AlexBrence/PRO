//
// Created by alex on 4/11/20.
//

#include "TextView.h"
#include <iostream>
#include <algorithm>

using namespace std;

TextView::TextView(Position position, Size size, string text) : View(position, size, true), text(text) {
}

void TextView::setText(const string &text) {
    this->text = text;
}

void TextView::setCapitalize(const bool &capitalize) {
    this->capitalize = capitalize;
}

string TextView::getText() const {
    return text;
}

bool TextView::isCapitalize() const {
    return capitalize;
}

void TextView::draw() const {
    View::draw();

    cout << "= TEXTVIEW OBJECT =\n Text: ";
    if (capitalize) {
        //transform(text.begin(), text.end(), text.begin(), ::toupper);
        cout << text <<  endl;
    } else {
        cout << text << endl;
    }
    cout << "Bool CAPITALIZE is set to ";
    capitalize ? cout << "true" : cout <<"false";

    cout << endl << endl;
}