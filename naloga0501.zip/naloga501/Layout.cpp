//
// Created by alex on 4/12/20.
//

#include "Layout.h"

void Layout::addView(View *view) {
    views.emplace_back(view);
}

View* Layout::getView(const int &position) const { // VRNE NASLOV, JE OK?
    for (auto view : views) {
        if (view->getPosition().getX() == position && view->getPosition().getY() == position) {
            return view;
        }
    }
    // ČE NE OBSTAJA, VRNE NEK NASLOV!
}

int Layout::size() const {
    return views.size();
}

void Layout::draw() const {     // VRNE NASLOV
    cout << "= Vector objects = " << endl;
    for (auto view : views) {
        cout << view << endl;
    }

    cout << endl;
}