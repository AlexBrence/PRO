#include <iostream>
#include "Position.h"
#include "Size.h"
#include "View.h"
#include "TextView.h"
#include "Layout.h"
#include "EditText.h"

using namespace std;


int main() {
    // POSITION, SIZE
    Position pozA(15, 12);
    cout << "X je " << pozA.getX() << endl;
    cout << "Y je " << pozA.getY() << endl;

    cout << "=== To string method ===" << endl;
    cout << pozA.toString() << endl;

    Size *a = new Size(15, 20, "Enota");
    cout << a->toString() << endl << endl;

    a->setHeight(10);
    cout << a->toString() << endl << endl;

    Size b(10, 15, "B Enota");
    View *view = new View(pozA, b, true);

    // VIEW
    cout << "=== VIEW ===" << endl;
    cout << "Position\n x: " << view->getPosition().getX() << ", y: " << view->getPosition().getY() << endl;
    cout << "Size\n Width: " << view->getSize().getWidth()
        << ", Height: " << view->getSize().getHeight()
        << ", Unit: " << view->getSize().getUnit() << endl << endl;
    view->setSize(20, 20, "Nova B enota");
    cout << "=== SET SIZE ===\n New size" << endl;
    cout << view->getSize().toString() << endl;

    cout << "=== SET POSITION ===" << endl;
    Position pozB(20, 20);
    view->setPosition(pozB);
    cout << "New position\n x: " << view->getPosition().getX() << ", y: " << view->getPosition().getY() << endl << endl;

    // View draw
    //view->setVisible(false);
    view->draw();

    // TEXTVIEW
    cout << "=== TEXTVIEW === " << endl;
    TextView *textview = new TextView(pozA, *a, "Tukaj gre text");
    textview->setCapitalize(true);
    textview->draw();

    // LAYOUT
    Layout layout;
    layout.addView(view);

    cout << "=== LAYOUT ===" << endl;

    cout << "= Layout size =\n " << layout.size() << endl;
    layout.draw();
    cout << "= Get view =\n " << layout.getView(55) << endl << endl;

    // EDIT TEXT
    EditText *et = new EditText(pozA, *a, "12.4.2020", InputType::date);
    cout << "Izpis EDITTEXT draw" << endl;
    layout.addView(et);
    et->draw();

    cout << "\n= Input type po spremembi =" << endl;
    et->setInputType(InputType::password);
    et->draw();
    layout.addView(textview);

    cout << "----- " << endl;
    layout.draw();


    return 0;
}
