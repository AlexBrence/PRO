//
// Created by alex on 4/11/20.
//

#include "Size.h"
#include <iostream>
#include <sstream>

using namespace std;


Size::Size(float width, float height, string unit) : width(width), height(height), unit(unit) {
}

void Size::setWidth(const float &width) {
    this->width = width;
}

void Size::setHeight(const float &height) {
    this->height = height;
}

void Size::setUnit(const string &unit) {
    this->unit = unit;
}

float Size::getWidth() const {
    return width;
}

float Size::getHeight() const {
    return height;
}

string Size::getUnit() const {
    return unit;
}

string Size::toString() const {
    stringstream info;
    info << "Width: " << width << "\nHeight: " << height << "\nUnit: " << unit;

    return info.str();
}
