//
// Created by alex on 4/11/20.
//

#include "View.h"
#include <iostream>

using namespace std;

View::View(Position position1, Size size1, bool visible = true) : position(position1), size(size1), visible(visible) {
}

void View::setPosition(const Position &position) {  // JE PRAVILEN TAKŠNA SET METODA
    this->position = position;
}

void View::setSize(const float &width, const float &height, const string &unit) {   // ALI TAKŠNA?
    this->size.setWidth(width);
    this->size.setHeight(height);
    this->size.setUnit(unit);
}

void View::setVisible(const bool &visible) {
    this->visible = visible;
}

Position View::getPosition() const {
    return position;
}

Size View::getSize() const {
    return size;
}

bool View::isVisible() const {
    return visible;
}

void View::draw() const {
    if (visible) {
        cout << "=== VIEW OBJECT ===" << endl;
        cout << "= Position =" << endl;
        cout << this->position.toString() << endl;
        cout << "= Size =" << endl;
        cout << this->size.toString() << endl;
    }
    cout << "Bool VISIBLE is set to ";
    visible ? cout << "true" : cout << "false";
    cout << endl << endl;
}