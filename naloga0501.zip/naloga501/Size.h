//
// Created by alex on 4/11/20.
//

#ifndef NALOGA501_SIZE_H
#define NALOGA501_SIZE_H
#include <istream>

using namespace std;

class Size {
private:
    float width, height;
    string unit;
public:
    Size(float width, float height, string unit);

    void setWidth(const float &width);
    void setHeight(const float &height);
    void setUnit(const string &unit);
    float getWidth() const;
    float getHeight() const;
    string getUnit() const;
    string toString() const;

};


#endif //NALOGA501_SIZE_H
