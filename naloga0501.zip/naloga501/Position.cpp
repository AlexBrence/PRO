//
// Created by alex on 4/11/20.
//

#include "Position.h"
#include <sstream>

using namespace std;

Position::Position(float x, float y) : x(x), y(y) {
}

float Position::getX() const {
    return x;
}

float Position::getY() const {
    return y;
}

string Position::toString() const {
    stringstream info;
    info << "X: " << x << "\nY: " << y;

    return info.str();
}
