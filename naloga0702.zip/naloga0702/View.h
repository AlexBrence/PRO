//
// Created by alex on 4/11/20.
//

#ifndef NALOGA501_VIEW_H
#define NALOGA501_VIEW_H
#include <iostream>
#include "Position.h"
#include "Size.h"
#include "Xml.h"

using namespace std;

class View {
protected:
    Position position;
    Size size;
    bool visible;
public:
    View(Position position1, Size size1, bool visible);

    // METODE
    void setPosition(const Position &position);
    void setSize(const float &width, const float &height, const Unit &unit);
    void setVisible(const bool &visible);
    Position getPosition() const;
    Size getSize() const;
    bool isVisible() const;
    virtual void draw() = 0;
    virtual string toXml() = 0;
};


#endif //NALOGA501_VIEW_H
