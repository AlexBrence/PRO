//
// Created by alex on 4/18/20.
//

#ifndef NALOGA501_BUTTON_H
#define NALOGA501_BUTTON_H

#include "TextView.h"
#include "View.h"

#include <iostream>
using namespace std;


class Button : public TextView {
private:
    bool enabled;
public:
    Button(const Position& position, const Size& size, string text);

    void setEnabled(const bool &e);
    bool isEnabled() const;
    void draw() const override;
    string toXml() const override;
    void onClick(const string &t) const;

    ~Button();
};


#endif //NALOGA501_BUTTON_H
