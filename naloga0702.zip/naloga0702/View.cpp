//
// Created by alex on 4/11/20.
//

#include "View.h"
#include <iostream>
#include <sstream>

using namespace std;


View::View() : position(), size(), visible(true) {
}

View::View(Position position1, Size size1) : position(position1), size(size1), visible(true){
}

void View::setPosition(const Position &position) {
    this->position = position;
}

void View::setSize(const float &width, const float &height, const Unit &unit) {
    this->size.setWidth(width);
    this->size.setHeight(height);
    this->size.setUnit(unit);
}

void View::setVisible(const bool &visible) {
    this->visible = visible;
}

Position View::getPosition() const {
    return position;
}

Size View::getSize() const {
    return size;
}

bool View::isVisible() const {
    return visible;
}

View::~View() {

}
