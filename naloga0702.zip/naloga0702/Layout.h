//
// Created by alex on 4/12/20.
//

#ifndef NALOGA501_LAYOUT_H
#define NALOGA501_LAYOUT_H

#include "View.h"
#include "Xml.h"
#include <iostream>
#include <vector>

using namespace std;


class Layout : public View {
private:
    vector<View*> views;
public:
    Layout(Position position, Size size, bool visible);

    void addView(View *view);
    View* getView(const int &position) const;
    int size() const;
    void draw() override;
    string toXml() override;
};


#endif //NALOGA501_LAYOUT_H
