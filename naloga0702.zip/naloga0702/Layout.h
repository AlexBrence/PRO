//
// Created by alex on 4/12/20.
//

#ifndef NALOGA501_LAYOUT_H
#define NALOGA501_LAYOUT_H

#include "View.h"
#include <iostream>
#include <vector>

using namespace std;


class Layout : public View {
private:
    vector<View*> views;
public:
    Layout();

    void addView(View *view);
    View* getView(const int &position) const;
    int size() const;
    void draw() const override;
    string toXml() const override;

    ~Layout();
};


#endif //NALOGA501_LAYOUT_H
