//
// Created by alex on 4/12/20.
//

#include "Layout.h"
#include <sstream>


Layout::Layout(Position position, Size size, bool visible = true) : View(position, size, visible) {
}

void Layout::addView(View *view) {
    views.emplace_back(view);
}

View* Layout::getView(const int &position) const { // VRNE NASLOV, JE OK?
    for (auto view : views) {
        if (view->getPosition().getX() == position && view->getPosition().getY() == position) {
            return view;
        }
    }
    // ČE NE OBSTAJA, VRNE NEK NASLOV!
}

int Layout::size() const {
    return views.size();
}

void Layout::draw() {
    for (auto view : views) {
        view->draw();
    }
    cout << endl;
}

string Layout::toXml() {
    stringstream xml;
    xml << "<Layout>\n";
    for (auto view : views) {
        xml << view->toXml();
    }
    xml << "</Layout>\n";

    return xml.str();
}


