//
// Created by alex on 4/11/20.
//

#include "TextView.h"
#include <iostream>
#include <sstream>
#include <utility>

using namespace std;


TextView::TextView(const Position& position, const Size& size, string text) : View(position, size), text(std::move(text)), capitalize(false) {
}

void TextView::setText(const string &text) {
    this->text = text;
}

void TextView::setCapitalize(const bool &capitalize) {
    if (capitalize && !isCapitalize()) {
        for (int i = 0; i < text.size(); i++) {
            if (text[i] == ' ')
                continue;
            if (text[i] >= 'a' && text[i] <= 'z')
                text[i] -= 32;
        }
    }
    else if (!capitalize && isCapitalize()) {
        for (int i = 0; i < text.size(); i++) {
            if (text[i] == ' ')
                continue;
            if (text[i] >= 'A' && text[i] <= 'Z')
                text[i] += 32;
        }
    }
    this->capitalize = capitalize;
}

string TextView::getText() const {
    return text;
}

bool TextView::isCapitalize() const {
    return capitalize;
}

TextView::~TextView() {

}

void TextView::draw() const {
    if (visible) {
        cout << "= TextView object =\n";
        cout << "Text: " << text << endl;
        cout << "CAPITALIZE is set to ";
        capitalize ? cout << "true" : cout << "false";
    }
    else
        cout << "!! The bool VISIBLE is set to false !!";

    cout << endl << endl;
}

string TextView::toXml() const {
    stringstream xml;
    xml << "\t<TextView\n";
    xml << "\t\twidth='" << size.getWidth() << size.getUnitInString() << "'\n";
    xml << "\t\theight='" << size.getHeight() << size.getUnitInString() << "'\n";
    xml << "\t\ttext='" << text << "'\n";
    xml << "\t\tvisible='";
    visible ? xml << "true'\n" : xml << "false'\n";
    xml << "\t\tcapitalize='";
    capitalize ? xml << "true' />\n" : xml << "false' />\n";

    return xml.str();
}