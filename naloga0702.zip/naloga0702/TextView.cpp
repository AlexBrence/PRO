//
// Created by alex on 4/11/20.
//

#include "TextView.h"
#include <iostream>
#include <sstream>

using namespace std;

// JE PRAV DA TU NASTAVIM DEFAULT VALUE?
TextView::TextView(Position position, Size size, string text, bool capitalize = false, bool visible = true) : View(position, size, visible), text(text), capitalize(capitalize) {
}

void TextView::setText(const string &text) {
    this->text = text;
}

void TextView::setCapitalize(const bool &capitalize) {
    if (capitalize && !isCapitalize()) {
        for (int i = 0; i < text.size(); i++) {
            if (text[i] == ' ')
                continue;
            if (text[i] >= 'a' && text[i] <= 'z')
                text[i] -= 32;
        }
    }
    else if (!capitalize && isCapitalize()) {
        for (int i = 0; i < text.size(); i++) {
            if (text[i] == ' ')
                continue;
            if (text[i] >= 'A' && text[i] <= 'Z')
                text[i] += 32;
        }
    }
    this->capitalize = capitalize;
}

string TextView::getText() const {
    return text;
}

bool TextView::isCapitalize() const {
    return capitalize;
}

void TextView::draw()  {
    if (visible) {
        cout << "= TextView object =\n";
        cout << "Text: " << text << endl;
        cout << "CAPITALIZE is set to ";
        capitalize ? cout << "true" : cout << "false";
    }
    else
        cout << "!! The bool VISIBLE is set to false !!";

    cout << endl << endl;
}

string TextView::toXml() {
    stringstream xml;
    xml << "\t<TextView\n";
    xml << "\t\twidth='" << size.getWidth() << size.getUnitInString() << "'\n";
    xml << "\t\theight='" << size.getHeight() << size.getUnitInString() << "'\n";
    xml << "\t\ttext='" << text << "'\n";
    xml << "\t\tvisible='";
    visible ? xml << "true'\n" : xml << "false'\n";
    xml << "\t\tcapitalize='";
    capitalize ? xml << "true' />\n" : xml << "false' />\n";

    return xml.str();
}