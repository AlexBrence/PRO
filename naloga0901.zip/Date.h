//
// Created by ALEX on 30. 05. 2020.
//

#ifndef NALOGA0901_DATE_H
#define NALOGA0901_DATE_H

#include <iostream>

using namespace std;

class Date {
private:
    int day;
    int month;
    int year;
public:
    Date();
    Date(int d, int m, int y);
    ~Date();

    int getDay() const;
    void setDay(const int &day);
    int getMonth() const;
    void setMonth(const int &month);
    int getYear() const;
    void setYear(const int &year);

    string toString() const;

    friend std::ostream& operator<<(std::ostream &out, const Date &date);
    bool operator==(const Date& other);
    Date& operator++();         // PREFIX
    Date operator++(int dummy); // POSTFIX
};
#endif //NALOGA0901_DATE_H
