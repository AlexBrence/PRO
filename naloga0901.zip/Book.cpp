//
// Created by ALEX on 1. 06. 2020.
//

#include "Book.h"
#include <sstream>
#include <ctime>

int Book::idCounter = 10000;

Book::Book() : title("Undefined"), publisher("Unknown"), pages(0), price(0), published(0) {
    idCounter += 1;
}

Book::Book(const Book& b) : title(b.title), publisher(b.publisher), pages(b.pages), price(b.price), published(b.published) {
    idCounter += 1;
}

Book::Book(string name, string email, char gender, string title, string publisher, int pages, double price, int published)
        : title(title), publisher(publisher), pages(pages), price(price), id(idCounter), published(published) {
    idCounter += 1;
}

Book::~Book() {
}

void Book::setTitle(const string &title) {
    this->title = title;
}

void Book::setPublisher(const string &publisher) {
    this->publisher = publisher;
}

void Book::setPages(const int &pages) {
    this->pages = pages;
}

void Book::setPrice(const double &price) {
    this->price = price;
}

void Book::setPublished(const int &year) {
    published = year;
}

string Book::getTitle() const {
    return title;
}

string Book::getPublisher() const {
    return publisher;
}

int Book::getPages() const {
    return pages;
}

double Book::getPrice() const {
    return price;
}

int Book::getPublished() const {
    return published;
}

void Book::print() const {
    cout << "ID: " << id << endl;
    cout << "Title: " << title << endl;
    cout << "Publisher: " << publisher << endl;
    cout << "Pages: " << pages << endl;
    cout << "Price: " << price << "€" << endl;
    cout << "Published: " << published << endl;
}

string Book::toString() const {
    stringstream ss;

    cout << "= Book Info =" << endl;
    ss << "ID: " << id << endl;
    ss << "\nTitle: " << title << endl;
    ss << "Publisher: " << publisher << endl;
    ss << "Pages: " << pages << endl;
    ss << "Price: " << price << "€" << endl;
    ss << "Published: " << published << endl;
    return ss.str();
}

int Book::getIdCounter()  {
    return idCounter;
}

Book Book::createDemoBook() {
    srand(time(0));

    string title[3] = {"Nebo in pesek", "Košarkar naj bo", "Rok in Janez"};
    string publisher[3] = {"Založba prva", "Založba Tanja", "Založba Sonček"};
    string AName[3] = {"Janko Padežnik", "Svetlana Makarovič", "Tone Pavček"};
    string AEmail[3] = {"jpadeznik@gmail.com", "smakarovic@gmail.com", "tpavcek@gmail.com"};
    char gender[2] = {'M', 'W'};
    int randomTitlePublisherAuthor = rand() % 3;
    int randomPages = rand() % 500 + 1;
    double randomPrice = rand() % 50 + 1;
    int randomGender = rand() % 2;
    int randomPublished = rand() % 30;

    return Book(AName[randomTitlePublisherAuthor], AEmail[randomTitlePublisherAuthor], gender[randomGender], title[randomTitlePublisherAuthor],
                publisher[randomTitlePublisherAuthor], randomPages, randomPrice, 1990 + randomPublished);
}

Book Book::operator+(int num) {
    pages += num;
    return *this;
}

Book Book::operator-(int num) {
    pages -= num;
    return *this;
}


