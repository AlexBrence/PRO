//
// Created by ALEX on 30. 05. 2020.
//

#ifndef NALOGA0901_SMARTPOINTER_H
#define NALOGA0901_SMARTPOINTER_H

#include <iostream>

using namespace std;

template <typename T>
class SmartPointer {
private:
    T *object;
public:
    SmartPointer(T* obj) : object(obj) {};
    ~SmartPointer() {cout << "SmartPointer dies here.\n"; delete object;};

    T& operator*() { return *object; };
    T* operator->() { return object; };
};



#endif //NALOGA0901_SMARTPOINTER_H
