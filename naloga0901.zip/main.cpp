#include <iostream>
#include <vector>
#include <memory>
#include "SmartPointer.h"
#include "Date.h"
#include "Book.h"

using namespace std;


std::ostream &operator<<(ostream &out, const Date &date) {
    out << date.getDay() << ". " << date.getMonth() << ". " << date.getYear();
    return out;
}

int main() {
    vector<shared_ptr<Book>> books;
    books.emplace_back(make_shared<Book>("Janko Nekič", "test@test.com", 'M', "Kolesar naj bo", "Sovica", 215, 24.99, 2008));
    books.emplace_back(make_shared<Book>("Manja Makro", "test@test3.com", 'W', "Sonce", "Sovica", 200, 15.99, 2007));

    for (auto &book : books) {
        *book = *book + 20;
        book->print();
        cout << endl;
    }
    cout << endl;

    {
        shared_ptr<Date> sp2;
        {
            cout << "=== Smart Pointer ===\n";
            SmartPointer<Date> date1(new Date(15, 4, 2020));
            cout << date1->toString() << endl << endl;

            shared_ptr<Date> sp = make_shared<Date>(1, 3, 2020);
            sp2 = sp;
        }
        cout << "Shared pointer sp2 still lives\n";
        cout << sp2->toString() << endl << endl;
    }

    cout << "=== Friend Function ===\n";
    Date datum(12, 3, 1999);
    cout << datum;

    return 0;
}
