//
// Created by ALEX on 1. 06. 2020.
//

#ifndef NALOGA0901_BOOK_H
#define NALOGA0901_BOOK_H

#include <iostream>
#include <vector>

using namespace std;

class Book {
private:
    string title, publisher;
    int pages;
    double price;
    int id;
    static int idCounter;
    int published;
public:
    Book();
    Book(const Book& b);
    Book(string name, string email, char gender, string title, string publisher, int pages, double price, int published);
    ~Book();

    void setTitle(const string &title);
    void setPublisher(const string &publisher);
    void setPages(const int &pages);
    void setPrice(const double &price);
    void setPublished(const int &year);
    string getTitle() const;
    string getPublisher() const;
    int getPages() const;
    double getPrice() const;
    int getPublished() const;
    void print() const;
    string toString() const;
    static int getIdCounter();
    static Book createDemoBook();

    Book operator+(int num);
    Book operator-(int num);
};

#endif //NALOGA0901_BOOK_H
