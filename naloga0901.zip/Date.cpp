//
// Created by ALEX on 30. 05. 2020.
//

#include "Date.h"
#include <sstream>

Date::Date() : day(00), month(00), year(0000) {
}

Date::Date(int d, int m, int y) : day(d), month(m), year(y) {
}

Date::~Date() {
}


int Date::getDay() const {
    return day;
}

void Date::setDay(const int &day) {
    this->day = day;
}

int Date::getMonth() const {
    return month;
}

void Date::setMonth(const int &month) {
    this->month = month;
}

int Date::getYear() const {
    return year;
}

void Date::setYear(const int &year) {
    this->year = year;
}

string Date::toString() const {
    stringstream ss;

    ss << day << ". " << month << ". " << year;
    return ss.str();
}


bool Date::operator==(const Date& other) {
    return (this->getDay() == other.getDay() && this->getMonth() == other.getMonth() && this->getYear() == other.getYear());
}

Date& Date::operator++() {
    int months[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (this->day == months[this->getMonth() - 1]) {
        if (this->getMonth() == 12) {
            this->year = this->year + 1;
            this->month = 1;
        }
        this->day = 1;
    }
    return *this;
}

Date Date::operator++(int dummy) {
    int months[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    Date tmp = *this;

    if (this->day == months[this->getMonth() - 1]) {
        if (this->getMonth() == 12) {
            this->year = this->year + 1;
            this->month = 1;
        }
        this->day = 1;
    }
    return tmp;
}