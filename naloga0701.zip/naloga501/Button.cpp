//
// Created by alex on 4/18/20.
//

#include "Button.h"
#include <sstream>
#include <iostream>
#include <utility>
using namespace std;

Button::Button(const Position& position, const Size& size, string text) : TextView(position, size, std::move(text)), enabled(true) {
}

void Button::setEnabled(const bool &e) {
    enabled = e;
}

bool Button::isEnabled() const {
    return enabled;
}

void Button::draw() const {
    cout << "= Button object =" << endl;
    cout << "Text: " << text << endl;
    cout << "ENABLED is set to: ";
    enabled ? cout << "true\n" : cout << "false\n";
}

string Button::toXml() const {
    stringstream xml;
    xml << "\t<Button\n";
    xml << "\t\twitdh='" << size.getWidth() << "'\n";
    xml << "\t\theight='" << size.getHeight() << "'\n";
    xml << "\t\ttext='" << text << "'\n";
    xml << "\t\tvisible='";
    visible ? xml << "true'\n" : xml << "false'\n";
    xml << "\t\tcapitalize='";
    capitalize ? xml << "true'\n" : xml << "false'\n";
    xml << "\t\tenabled='";
    enabled ? xml << "true' />\n" : xml << "false' />\n";

    return xml.str();
}

void Button::onClick(const string &t) const {
    enabled ? cout << t << endl : cout << "";
}

string Button::onClick() const {
    return "Button";
}

Button::~Button() {

}
