//
// Created by alex on 4/11/20.
//

#ifndef NALOGA501_VIEW_H
#define NALOGA501_VIEW_H
#include <iostream>
#include "Position.h"
#include "Size.h"
#include "ClickListener.h"
#include "Xml.h"

using namespace std;

class View : public ClickListener, public Xml {
protected:
    Position position;
    Size size;
    bool visible;
public:
    View();
    View(Position position1, Size size1);

    // METODE
    void setPosition(const Position &position);
    void setSize(const float &width, const float &height, const Unit &unit);
    void setVisible(const bool &visible);
    Position getPosition() const;
    Size getSize() const;
    bool isVisible() const;
    virtual void draw() const = 0;

    virtual ~View();
};


#endif //NALOGA501_VIEW_H
