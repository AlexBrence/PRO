//
// Created by alex on 4/11/20.
//

#ifndef NALOGA501_POSITION_H
#define NALOGA501_POSITION_H
#include <iostream>

using namespace std;

class Position {
private:
    float x, y;
public:
    Position(float x, float y);

    // METODE
    float getX() const;
    float getY() const;
    string toString() const;
};


#endif //NALOGA501_POSITION_H
