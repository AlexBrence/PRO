//
// Created by alex on 4/11/20.
//

#include "Size.h"
#include <iostream>
#include <sstream>

using namespace std;


Size::Size(float width, float height, Unit unit) : width(width), height(height), unit(unit) {
}

void Size::setWidth(const float &width) {
    this->width = width;
}

void Size::setHeight(const float &height) {
    this->height = height;
}

void Size::setUnit(const Unit &unit) {
    this->unit = unit;
}

float Size::getWidth() const {
    return width;
}

float Size::getHeight() const {
    return height;
}

Unit Size::getUnit() const {
    return unit;
}

string Size::getUnitInString() const {
    stringstream u;
    switch(unit) {
        case Unit::mm :
            u << "mm";
            break;
        case Unit::cm :
            u << "cm";
            break;
        case Unit::px :
            u << "px";
            break;
        case Unit::dp :
            u << "dp";
            break;
    }

    return u.str();
}

string Size::toString() const {
    stringstream info;
    info << "Width: " << width << ", Height: " << height << ", Unit: " << getUnitInString();

    return info.str();
}
