//
// Created by alex on 4/14/20.
//

#include "EditText.h"

EditText::EditText(Position position, Size size, string text, InputType inputType)
                : TextView(position, size, text), inputType(inputType) {
}

void EditText::setInputType(const InputType &inputType) {
    if (inputType < InputType::number || inputType > InputType::password) {
        cout << "Wrong choice." << endl;
    } else {
        this->inputType = inputType;
    }
}

string EditText::getInputType() const {
    switch(inputType) {
        case InputType::number :
            return "Number";
            break;
        case InputType::decimalNumber :
            return "Decimal number";
            break;
        case InputType::date :
            return "Date";
            break;
        case InputType::time :
            return "Time";
            break;
        case InputType::email :
            return "E-mail";
            break;
        case InputType::phone :
            return "Phone";
            break;
        case InputType::password :
            return "Password";
            break;
        default:
            return "Unknown";
            break;
    }
}

void EditText::draw() const {
    TextView::draw();

    cout << "The input type is " << getInputType() << endl;
}

EditText::~EditText() {

}
