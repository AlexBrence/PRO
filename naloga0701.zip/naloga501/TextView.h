//
// Created by alex on 4/11/20.
//

#ifndef NALOGA501_TEXTVIEW_H
#define NALOGA501_TEXTVIEW_H
#include <iostream>
#include "View.h"

using namespace std;


class TextView : public View {
protected:
    string text;
    bool capitalize;
public:
    TextView(Position position, Size size, string text);
    void setText(const string &text);
    void setCapitalize(const bool &capitalize);
    string getText() const;
    bool isCapitalize() const;
    void draw() const override;

    string toXml() const override;
    string onClick() const override;

    ~TextView() override;
};


#endif //NALOGA501_TEXTVIEW_H
