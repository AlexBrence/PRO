#include <iostream>
#include "Position.h"
#include "Size.h"
#include "View.h"
#include "TextView.h"
#include "Layout.h"
#include "EditText.h"
#include "Button.h"

using namespace std;


int main() {
    Layout layout;
    layout.addView(new TextView(Position(0, 0), Size(1, 2, Unit::mm), "Nek text pač"));
    layout.addView(new TextView(Position(1, 5), Size(4, 5.5, Unit::mm), "Lorem upusun jkdkshen"));
    layout.addView(new TextView(Position(20, 20), Size(20, 15.2, Unit::px), "Lorem ipsum"));
    layout.addView(new TextView(Position(5, 2.5), Size(2, 12.3, Unit::dp), "Samo lorem"));
    layout.addView(new Button(Position(5, 5), Size(12, 7.5, Unit::mm), "Gumbić"));


    layout.getView(0)->setVisible(false);

    ((TextView*)layout.getView(20))->setCapitalize(true); // RAZLOŽITEV
    cout << layout.toXml();

    cout << "\n\n=== Draw ===" << endl;
    layout.draw();

    cout << "=== On Click ===\n";
    layout.onClick();

    return 0;
}
