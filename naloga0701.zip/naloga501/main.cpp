#include <iostream>
#include "Position.h"
#include "Size.h"
#include "View.h"
#include "TextView.h"
#include "Layout.h"
#include "EditText.h"
#include "Button.h"

using namespace std;


int main() {
    Position *pos1 = new Position(12, 13);
    Position *pos2 = new Position(10, 10);
    Position *pos3 = new Position(20, 20);
    Position *pos4 = new Position(5, 5);
    Position *pos5 = new Position(20, 15.5);

    Size *s1 = new Size(10, 11, Unit::mm);
    Size *s2 = new Size(5, 5, Unit::mm);
    Size *s3 = new Size(20, 15.2, Unit::px);
    Size *s4 = new Size(2, 2.5, Unit::dp);
    Size *s5 = new Size(10, 2, Unit::mm);

    TextView *tw1 = new TextView(*pos1, *s1, "Lorem ipsum pa še nekaj zraven", false, true);
    TextView *tw2 = new TextView(*pos2, *s2, "Lorem ipsum pa še neakj", true, true);
    TextView *tw3 = new TextView(*pos3, *s3, "Lorem ipsum", false, false);
    TextView *tw4 = new TextView(*pos4, *s4, "Samo lorem", true, true);
    TextView *tw5 = new TextView(*pos5, *s5, "Še zadnji", false, true);

    Button *b1 = new Button(*pos1, *s1, "Gumb", true);

    Layout *layout = new Layout();
    layout->addView(tw1);
    layout->addView(tw2);
    layout->addView(tw3);
    layout->addView(tw4);
    layout->addView(tw5);
    layout->addView(b1);

    cout << "=== TO XML ===" << endl;
    cout << layout->toXml();

    cout << "\n=== On Click Method ===" << endl;
    b1->onClick("Nek text ki se izpiše");
    b1->setEnabled(false);
    b1->onClick("Nek text ki se ne bo izpisal");

    cout << "=== Draw Method ===" << endl;
    layout->draw();



    delete pos1;
    delete pos2;
    delete pos3;
    delete pos4;
    delete pos5;
    delete s1;
    delete s2;
    delete s3;
    delete s4;
    delete s5;
    delete tw1;
    delete tw2;
    delete tw3;
    delete tw4;
    delete tw5;
    delete b1;
    delete layout;

    return 0;
}
