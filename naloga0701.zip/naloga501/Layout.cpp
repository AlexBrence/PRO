//
// Created by alex on 4/12/20.
//

#include "Layout.h"
#include <sstream>


Layout::Layout() {
}

void Layout::addView(View *view) {
    views.emplace_back(view);
}

View* Layout::getView(const int &position) const {
    for (auto view : views) {
        if (view->getPosition().getX() == position && view->getPosition().getY() == position) {
            return view;
        }
    }
    // ČE NE OBSTAJA, VRNE NEK NASLOV!
}

int Layout::size() const {
    return views.size();
}

void Layout::draw() const {
    for (auto view : views) {
        view->draw();
    }
    cout << endl;
}

string Layout::toXml() const {
    stringstream xml;
    xml << "<Layout>\n";
    for (auto view : views) {
        xml << view->toXml();
    }
    xml << "</Layout>\n";

    return xml.str();
}

string Layout::onClick() const {
    for (auto view : views) {
        cout << view->onClick() << endl;
    }
}