//
// Created by alex on 4/14/20.
//

#ifndef NALOGA501_EDITTEXT_H
#define NALOGA501_EDITTEXT_H
#include <iostream>
#include "TextView.h"


enum class InputType {
    number,
    decimalNumber,
    date,
    time,
    email,
    phone,
    password
};

class EditText : public TextView {
private:
    InputType inputType;
public:
    EditText(Position position, Size size, string text, InputType inputType);

    void setInputType(const InputType &inputType);
    string getInputType() const;
    void draw() const override;

    ~EditText() override;
};


#endif //NALOGA501_EDITTEXT_H
