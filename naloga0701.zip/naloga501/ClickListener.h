//
// Created by alex on 4/20/20.
//

#ifndef NALOGA501_CLICKLISTENER_H
#define NALOGA501_CLICKLISTENER_H

#endif //NALOGA501_CLICKLISTENER_H

#include <iostream>

class ClickListener {
public:
    virtual std::string onClick() const = 0;
};