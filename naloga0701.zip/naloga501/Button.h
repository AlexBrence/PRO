//
// Created by alex on 4/18/20.
//

#ifndef NALOGA501_BUTTON_H
#define NALOGA501_BUTTON_H

#include "TextView.h"
#include "View.h"

#include <iostream>
using namespace std;


class Button : public TextView {
private:
    bool enabled;
public:
    Button(Position position, Size size, string text, bool enabled);

    void setEnabled(const bool &e);
    bool isEnabled() const;
    void draw() override;
    string toXml() override;
    void onClick(const string &t) const;
};


#endif //NALOGA501_BUTTON_H
