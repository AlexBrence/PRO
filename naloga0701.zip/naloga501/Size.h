//
// Created by alex on 4/11/20.
//

#ifndef NALOGA501_SIZE_H
#define NALOGA501_SIZE_H
#include <istream>

using namespace std;

enum class Unit {
    mm, cm, px, dp
};


class Size {
private:
    float width, height;
    Unit unit;
public:
    Size(float width, float height, Unit unit);

    void setWidth(const float &width);
    void setHeight(const float &height);
    void setUnit(const Unit &unit);
    float getWidth() const;
    float getHeight() const;
    Unit getUnit() const;
    string toString() const;
    string getUnitInString() const;

};


#endif //NALOGA501_SIZE_H
