//
// Created by alex on 4/18/20.
//

#ifndef NALOGA501_XML_H
#define NALOGA501_XML_H

#include <iostream>
using namespace std;

class Xml {
public:
    virtual string toXml() = 0;
};


#endif //NALOGA501_XML_H
