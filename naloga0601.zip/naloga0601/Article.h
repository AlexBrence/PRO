//
// Created by alex on 4/12/20.
//

#ifndef NALOGA0601_ARTICLE_H
#define NALOGA0601_ARTICLE_H

#include <iostream>
using namespace std;


class Article {
protected:
    string name, barcode;
    double price, quantity;
public:
    Article(string n, string b, double p);

    void setName(const string &name);
    void setBarcode(const string &bacrode);
    void setPrice(const double &price);
    void setQuantity(const double &quantity);
    string getName() const;
    string getBarcode() const;
    double getPrice() const;
    double getQuantity() const;
    bool hasSameCode(const Article *a);
    double getTotalPrice() const;
    virtual string toString() const;
};


#endif //NALOGA0601_ARTICLE_H
