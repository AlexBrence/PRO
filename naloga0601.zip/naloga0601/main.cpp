#include <iostream>
#include <vector>
#include "Article.h"
#include "WeighableArticle.h"
#include "Datetime.h"
#include "Invoice.h"

using namespace std;

int main() {
    vector<Invoice*> invoice;

    // PRVI
    Article *cips = new Article("Čips", "xcips", 1.22);
    cips->setQuantity(2);
    Article *pepsi = new Article("Pepsi", "xpeps", 1.12);
    Article *coko = new Article("Čokolada", "xcoko", 2.15);

    Invoice *prvi = new Invoice("Hofer d.o.o.");
    prvi->addArticle(cips);
    prvi->addArticle(pepsi);
    prvi->addArticle(coko);

    // DRUGI
    Article *mleko = new Article("Mleko", "xml", 1.78);
    mleko->setQuantity(2);
    mleko->setPrice(2.50);
    WeighableArticle *banane = new WeighableArticle("Banane", "xban", 1.87, 2.35);
    WeighableArticle *kivi = new WeighableArticle("Kivi", "xkivi", 2.64, 1.58);

    Invoice *drugi = new Invoice("Tuš d.o.o.");
    drugi->addArticle(mleko);
    drugi->addArticle(banane);
    drugi->addArticle(kivi);

    invoice.emplace_back(prvi);
    invoice.emplace_back(drugi);

    for (auto singleInvoice : invoice) {
        singleInvoice->print();
        cout << endl << endl;
    }



    return 0;
}
