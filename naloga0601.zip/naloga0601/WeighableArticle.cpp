//
// Created by alex on 4/12/20.
//

#include "WeighableArticle.h"
#include <sstream>
#include <utility>

WeighableArticle::WeighableArticle(string n, string b, double p, double q) : Article(std::move(n), std::move(b), p) {
    this->setQuantity(q);
}

string WeighableArticle::toString() const {
    stringstream info;

    info << name << " " << quantity << "kg " << price << "€";
    return info.str();
}