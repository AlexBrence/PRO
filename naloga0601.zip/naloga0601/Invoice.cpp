//
// Created by alex on 4/12/20.
//

#include "Invoice.h"

int Invoice::countId = 1;

Invoice::Invoice(string seller) : seller(seller) {
    id = countId;
    countId++;
}

void Invoice::addArticle(Article *a) {
    bool same = false;
    for (auto article : articles) {
        if (a->hasSameCode(article)) {
            article->setQuantity(article->getQuantity() + a->getQuantity());
            same = true;
        }
    }
    if (!same)
        articles.emplace_back(a);
}

void Invoice::print() const {
    double sum = 0;

    cout << seller << " Račun št. " << this->id << endl;
    cout << "Datum: " << Datetime::now();
    for (auto article : articles) {
        cout << article->toString() << endl;
        sum += article->getTotalPrice();
    }
    cout << "Skupaj: " << sum  << "€" << endl << endl;
}