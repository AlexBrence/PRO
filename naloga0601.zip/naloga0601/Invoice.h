//
// Created by alex on 4/12/20.
//

#ifndef NALOGA0601_INVOICE_H
#define NALOGA0601_INVOICE_H

#include <iostream>
#include <vector>
#include "Article.h"
#include "Datetime.h"
using namespace std;

class Invoice {
private:
    vector<Article*> articles;
    string seller;
    int id;
    static int countId;
public:
    Invoice(string seller);

    void addArticle(Article *a);
    void print() const;
};


#endif //NALOGA0601_INVOICE_H
