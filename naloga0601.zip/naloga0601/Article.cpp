//
// Created by alex on 4/12/20.
//

#include "Article.h"
#include <sstream>


Article::Article(string n, string b, double p) : name(n), barcode(b), price(p), quantity(1) {
}

void Article::setName(const string &name) {
    this->name = name;
}

void Article::setBarcode(const string &barcode) {
    this->barcode = barcode;
}

void Article::setPrice(const double &price) {
    this->price = price;
}

void Article::setQuantity(const double &quantity) {
    this->quantity = quantity;
}

string Article::getName() const {
    return name;
}

string Article::getBarcode() const {
    return barcode;
}

double Article::getPrice() const {
    return price;
}

double Article::getQuantity() const {
    return quantity;
}

bool Article::hasSameCode(const Article *a) {
    return (this->barcode == a->barcode);
}

double Article::getTotalPrice() const {
    return (this->quantity * this->price);
}

string Article::toString() const {
    stringstream info;
    info << name << " " << quantity << " " << price << "€";

    return info.str();
}
