//
// Created by alex on 4/12/20.
//

#include "Datetime.h"
#include <sstream>

string Datetime::now() {
    stringstream date;
    std::time_t t = std::time(0);   // get time now
    std::tm* now = std::localtime(&t);
    date << (now->tm_year + 1900) << '-'
              << (now->tm_mon + 1) << '-'
              <<  now->tm_mday
              << "\n";

    return date.str();

}
