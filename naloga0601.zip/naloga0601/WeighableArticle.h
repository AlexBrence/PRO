//
// Created by alex on 4/12/20.
//

#ifndef NALOGA0601_WEIGHABLEARTICLE_H
#define NALOGA0601_WEIGHABLEARTICLE_H

#include <iostream>
#include "Article.h"
using namespace std;

class WeighableArticle : public Article {
public:
    WeighableArticle(string n, string b, double p, double q);

    string toString() const override;
};


#endif //NALOGA0601_WEIGHABLEARTICLE_H
