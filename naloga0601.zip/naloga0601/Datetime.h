//
// Created by alex on 4/12/20.
//

#ifndef NALOGA0601_DATETIME_H
#define NALOGA0601_DATETIME_H

#include <iostream>
#include <ctime>
using namespace std;


class Datetime {
public:
    static string now();
};


#endif //NALOGA0601_DATETIME_H
