//
// Created by alex on 5/4/20.
//

#include "Person.h"
#include <sstream>

Person::Person() {
}

Person::Person(string n, int a) : name(n), age(a) {
}

Person::~Person() {

}

void Person::setName(const string &name) {
    this->name = name;
}

string Person::getName() const {
    return name;
}

void Person::setAge(const int &age) {
    this->age = age;
}

int Person::getAge() const {
    return age;
}

string Person::toString() const {
    stringstream ss;
    ss << "Name: " << name;
    ss << ", Age: " << age;

    return ss.str();
}
