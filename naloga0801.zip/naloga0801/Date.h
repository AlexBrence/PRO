//
// Created by alex on 5/4/20.
//

#ifndef NALOGA0801_DATE_H
#define NALOGA0801_DATE_H
#include <iostream>

using namespace std;

class Date {
private:
    int day;
    int month;
    int year;
public:
    Date();
    Date(int d, int m, int y);
    ~Date();

    int getDay() const;
    void setDay(const int &day);
    int getMonth() const;
    void setMonth(const int &month);
    int getYear() const;
    void setYear(const int &year);

    string toString() const;
};


#endif //NALOGA0801_DATE_H
