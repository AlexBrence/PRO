//
// Created by alex on 5/4/20.
//

#include "Date.h"
#include <sstream>

Date::Date() : day(00), month(00), year(0000) {
}

Date::Date(int d, int m, int y) : day(d), month(m), year(y) {
}

Date::~Date() {
}


int Date::getDay() const {
    return day;
}

void Date::setDay(const int &day) {
    this->day = day;
}

int Date::getMonth() const {
    return month;
}

void Date::setMonth(const int &month) {
    this->month = month;
}

int Date::getYear() const {
    return year;
}

void Date::setYear(const int &year) {
    this->year = year;
}

string Date::toString() const {
    stringstream ss;

    ss << day << ". " << month << ". " << year;
    return ss.str();
}
