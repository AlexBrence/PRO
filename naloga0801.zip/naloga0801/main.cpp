#include <iostream>
#include <vector>
#include "Date.h"
#include "Person.h"

using namespace std;

/* PRIMERI ŠABLON FUNKCIJ IZ INTERNETA
 * https://www.youtube.com/watch?v=7SqySe4Lkow
 * https://www.youtube.com/watch?v=I-hZkUa9mIs
 * https://www.geeksforgeeks.org/templates-cpp/
*/


template <typename T>
void printVector(const vector<T> &values) {
    for (const auto &value : values)
        cout << value << ", ";
    cout << endl;
}

template <>
void printVector(const vector<Date>& values) {
    for (const auto &date : values) {
        cout << date.toString() << endl;
    }
    cout << endl;
}

template<>
void printVector(const vector<Person>& values) {
    for (const auto& person : values)
        cout << person.toString() << endl;
    cout << endl;
}


template <typename T>
void reorder(T &first, T &second) {
    T tmp = first;
    first = second;
    second = tmp;
}

template <typename T>
bool isAfter(const T &first, const T &second) {
    return (first < second);
}

template<>
bool isAfter(const Date &first, const Date &second) {
    if (first.getYear() < second.getYear())
        return true;
    else if (first.getYear() == second.getYear()) {
        if (first.getMonth() < second.getMonth())
            return true;
        else if (first.getMonth() == second.getMonth()) {
            return (first.getDay() < second.getDay());
        }
    }
    return false;
}


template<>
bool isAfter(const string &first, const string &second) {
    return (first.length() < second.length());
}

template<>
bool isAfter(const Person &first, const Person &second) {
    return (first.getAge() < second.getAge());
}


template <typename T>
void bubbleSort(vector<T> &values) {
    int N = values.size();

    for (int i = 0; i < N-1; i++) {
        for (int j = 0; j < N - i - 1; j++) {
            if (!isAfter(values[j], values[j+1]))
                reorder(values[j], values[j + 1]);
        }
    }
}



int main() {
    // INTEGERS
    cout << "=== Example with integers ===\n";
    vector<int> integers = {4, 62, 2, 45, 6, 3, 61, 27, 15};
    cout << "Unsorted: ";
    printVector<int>(integers);     // EKSPLICITNO INSTANCIRANJE ŠABLONE
    bubbleSort(integers);
    cout << "Sorted: ";
    printVector(integers);         // IMPLICITNO INSTANCIRANJE ŠABLONE

    // STRINGS
    cout << "\n=== Example with strings ===\n";
    vector<string> strings = {"ena", "dva", "petnajst", "s", "dark", "tabonajdaljsistring", "vr"};
    cout << "Unsorted: ";
    printVector(strings);
    bubbleSort(strings);
    cout << "Sorted: ";
    printVector(strings);

    // DATE OBJECTS
    cout << "\n=== Example with Date objects ===\n";
    Date date1(12, 4, 2020);
    Date date2(3, 4, 2020);
    Date date3(19, 6, 2019);
    Date date4(16, 2, 2020);
    vector<Date> dates = {date1, date2, date3, date4};
    cout << "Unsorted: ";
    printVector(dates);
    bubbleSort(dates);
    cout << "Sorted: ";
    printVector(dates);

    // PERSON OBJECTS
    cout << "\n=== Example with Person objects ===\n";
    Person p1("Jure", 15);
    Person p2("Jaka", 25);
    Person p3("Anja", 55);
    Person p4("Ziga", 5);
    Person p5("Matic", 1);
    vector<Person> persons = {p1, p2, p3, p4, p5};
    cout << "Unsorted: " << endl;
    printVector(persons);
    bubbleSort(persons);
    cout << "Sorted: " << endl;
    printVector(persons);


    return 0;
}
