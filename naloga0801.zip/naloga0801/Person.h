//
// Created by alex on 5/4/20.
//

#ifndef NALOGA0801_PERSON_H
#define NALOGA0801_PERSON_H
#include <iostream>

using namespace std;


class Person {
private:
    string name;
    int age;
public:
    Person();
    Person(string n, int a);
    ~Person();

    void setName(const string &name);
    string getName() const;
    void setAge(const int &age);
    int getAge() const;
    string toString() const;
};


#endif //NALOGA0801_PERSON_H
