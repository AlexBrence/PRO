//
// Created by ALEX on 1. 06. 2020.
//

#include "Athlete.h"
#include <sstream>
#include <fstream>
#include "FilenameException.h"
#include "InvalidAthleteId.h"
#include <algorithm>
#include <functional>


Athlete::Athlete(int id, string fn, string ln, Date bd, string c) : id(id), firstName(fn), lastName(ln),
                    birthDate(bd), country(c) {
    if (to_string(id).length() != 8) {
        throw InvalidAthleteId();
    }
}

string Athlete::toString() const {
    stringstream ss;
    ss << id << " " << firstName << " " << lastName << " " << birthDate.toString() << " " << country;

    return ss.str();
}

int Athlete::getAge(const Date &currentDate) const {
    return (currentDate.getYear() - birthDate.getYear());
}

vector<Athlete> Athlete::loadFromFile(const string &filename) {
        vector<Athlete> athletes;
        string ID, fn, ln, bd, c, line;

        ifstream ifs(filename);
        if (ifs.is_open()) {
            while (getline(ifs, line)) {
                istringstream iss(line);
                getline(iss, ID, ',');
                getline(iss, fn, ',');
                getline(iss, ln, ',');
                getline(iss, bd, ',');
                getline(iss, c, '\n');
                try {
                    Date tmp = Date::getDateFromString(bd);
                    int idNum = stoi(ID);
                    Athlete a(idNum, fn, ln, tmp, c);
                    athletes.push_back(a);

                    if (ID.length() != 8) {
                        throw InvalidAthleteId();
                    }
                    for (int i = 0; i < 8; i++) {
                        if ((ID[i] > 'a' && ID[i] < 'z') || (ID[i] > 'A' && ID[i] < 'Z')) {
                            throw InvalidAthleteId();
                        }
                    }
                } catch (InvalidAthleteId ex)  {
                    cout << ex.what() << endl;
                /}


            }
            ifs.close();
            return athletes;
        } else {
            throw FilenameException();
        }
}

void Athlete::sortAthletes(vector<Athlete> &athletes, bool (*c)(const Athlete &, const Athlete &)) {
    std::sort(athletes.begin(), athletes.end(), c);
}


