//
// Created by ALEX on 31. 05. 2020.
//

#ifndef NALOGA1001_UNPARSEABLEDATEEXCEPTION_H
#define NALOGA1001_UNPARSEABLEDATEEXCEPTION_H

#include <iostream>

using namespace std;

class UnparseableDateException : public std::exception {
private:
    string message;
public:
    UnparseableDateException(const string& wrongDate);

    const char* what() const noexcept override;
};


#endif //NALOGA1001_UNPARSEABLEDATEEXCEPTION_H
