//
// Created by ALEX on 1. 06. 2020.
//

#ifndef NALOGA1001_INVALIDATHLETEID_H
#define NALOGA1001_INVALIDATHLETEID_H


#include <iostream>

using namespace std;

class InvalidAthleteId : public std::exception{
private:
    string message;
public:
    InvalidAthleteId();
    void print() const;

    const char* what() const noexcept override;
};


#endif //NALOGA1001_INVALIDATHLETEID_H
