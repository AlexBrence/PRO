//
// Created by ALEX on 1. 06. 2020.
//

#ifndef NALOGA1001_ATHLETE_H
#define NALOGA1001_ATHLETE_H

#include <iostream>
#include "Date.h"
#include <vector>

using namespace std;


class Athlete {
private:
    int id;
    string firstName;
    string lastName;
    Date birthDate;
    string country;
public:
    Athlete(int id, string fn, string ln, Date bd, string c);

    string toString() const;
    int getAge(const Date &currentDate) const;

    static vector<Athlete> loadFromFile(const string &filename);
    static void sortAthletes(std::vector<Athlete> &athletes, bool (*c)(const Athlete&, const Athlete&));

};


#endif //NALOGA1001_ATHLETE_H
