#include <iostream>
#include "UnparseableDateException.h"
#include "Athlete.h"
#include "Date.h"
#include "FilenameException.h"
#include "InvalidAthleteId.h"
#include <vector>

using namespace std;



Date currentDate (1, 6, 2020);

bool ascendingAges(const Athlete &athlete1, const Athlete &athlete2) {
    return (athlete1.getAge(currentDate) < athlete2.getAge(currentDate));
}

bool descendingAges(const Athlete &athlete1, const Athlete &athlete2) {
    return (athlete1.getAge(currentDate) > athlete2.getAge(currentDate));
}


int main() {
    vector<Athlete> athletes;

    cout << "=== Load From File ===\n";
    try {
        athletes = Athlete::loadFromFile(R"(C:\Users\ALEX\CLionProjects\PRO\naloga1001\athletes.csv)");

        cout << "=== Get Date From String ===\n";
        Date date1 = Date::getDateFromString("12.33.2020");

        Athlete a(1234567, "Janko", "Jankic", Date(22, 5, 1997), "Japonska");

    }
    catch (const FilenameException& fe) {
        cout << fe.what() << endl;
    }
    catch (const InvalidAthleteId& e) {
        cout << e.what() << endl;
    }
    catch (const UnparseableDateException& ude) {
        cout << ude.what() << endl;
    }
    cout << endl;




    cout << "=== Athletes To String ===\n";
    for (auto a : athletes) {
        cout << a.toString() << endl;
    }

    cout << "=== Sort Athletes by Age ===\nAscending:\n";
    Athlete::sortAthletes(athletes, ascendingAges);
    for (auto a : athletes) {
        cout << a.toString() << endl;
    }

    cout << "\nDescending:\n";
    Athlete::sortAthletes(athletes, descendingAges);
    for (auto a : athletes) {
        cout << a.toString() << endl;
    }


    return 0;
}
