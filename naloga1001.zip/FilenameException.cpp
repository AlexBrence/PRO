//
// Created by ALEX on 1. 06. 2020.
//

#include "FilenameException.h"

FilenameException::FilenameException() : message("Filename exception") {
}

void FilenameException::print() const {
    cout << message << endl;
}

const char *FilenameException::what() const noexcept {
    return message.c_str();
}
