//
// Created by ALEX on 1. 06. 2020.
//

#include "InvalidAthleteId.h"

InvalidAthleteId::InvalidAthleteId() : message("Napaka, id mora biti iz 8 stevil!") {
}

void InvalidAthleteId::print() const {
    cout << message << endl;
}

const char *InvalidAthleteId::what() const noexcept {
    return message.c_str();
}

