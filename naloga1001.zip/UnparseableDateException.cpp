//
// Created by ALEX on 31. 05. 2020.
//

#include "UnparseableDateException.h"

UnparseableDateException::UnparseableDateException(const string& wrongDate) {
    message = "Unparseable date: " + wrongDate;
}

const char *UnparseableDateException::what() const noexcept {
    return message.c_str();
}
