//
// Created by ALEX on 31. 05. 2020.
//


#include "Date.h"
#include "UnparseableDateException.h"
#include <sstream>

Date::Date() : day(00), month(00), year(0000) {
}

Date::Date(int d, int m, int y) : day(d), month(m), year(y) {
}

Date::~Date() {
}


int Date::getDay() const {
    return day;
}

void Date::setDay(const int &day) {
    this->day = day;
}

int Date::getMonth() const {
    return month;
}

void Date::setMonth(const int &month) {
    this->month = month;
}

int Date::getYear() const {
    return year;
}

void Date::setYear(const int &year) {
    this->year = year;
}

string Date::toString() const {
    stringstream ss;

    ss << day << month << year;
    return ss.str();
}

Date Date::getDateFromString(const string &date) {
        int dotIndex = 0;
        string d = "";
        string m = "";
        string y = "";
        int iD, iM, iY;


        for (int i = 0; i < date.length(); i++) {
            if (date[i] == '.') {
                dotIndex++;
                continue;
            }
            if (dotIndex == 0)
                d += date[i];
            if (dotIndex == 1)
                m += date[i];
            if (dotIndex == 2)
                y += date[i];
        }

        stringstream day(d);
        stringstream month(m);
        stringstream year(y);

        if (d.length() > 2) {
            throw UnparseableDateException(d);
        }
        else if (m.length() > 2) {
            throw UnparseableDateException(m);
        }
        else if (y.length() != 4) {
            throw UnparseableDateException(y);
        }

        day >> iD;
        month >> iM;
        year >> iY;
        Date tmp(iD, iM, iY);


        if (dotIndex != 2)
            throw UnparseableDateException(to_string(dotIndex));


        for (int i = 0; i < date.length(); i++) {
            if (((date[i] <= 'z' && date[i] >= 'a') || (date[i] <= 'Z' && date[i] >= 'A')) && date[i] != '.')
                throw UnparseableDateException(to_string((date[i])));
        }

        return tmp;

}
