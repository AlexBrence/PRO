//
// Created by ALEX on 31. 05. 2020.
//

#ifndef NALOGA1001_DATE_H
#define NALOGA1001_DATE_H

#include <iostream>

using namespace std;

class Date {
private:
    int day;
    int month;
    int year;
public:
    Date();
    Date(int d, int m, int y);
    ~Date();

    int getDay() const;
    void setDay(const int &day);
    int getMonth() const;
    void setMonth(const int &month);
    int getYear() const;
    void setYear(const int &year);

    string toString() const;

    static Date getDateFromString(const string& date);
};

#endif //NALOGA1001_DATE_H
